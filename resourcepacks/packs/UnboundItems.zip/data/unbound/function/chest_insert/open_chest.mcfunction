

execute anchored eyes positioned ^ ^ ^ if entity @s[advancements={unbound:chest/minecraft/simple_dungeon=true}] run function unbound:chest_insert/raycast/minecraft/simple_dungeon

execute anchored eyes positioned ^ ^ ^ if entity @s[advancements={unbound:chest/forsaken/jewels=true}] run function unbound:chest_insert/raycast/forsaken/jewels

execute anchored eyes positioned ^ ^ ^ if entity @s[advancements={unbound:chest/forsaken/forge=true}] run function unbound:chest_insert/raycast/forsaken/forge

execute anchored eyes positioned ^ ^ ^ if entity @s[advancements={unbound:chest/minecraft/ancient_city=true}] run function unbound:chest_insert/raycast/minecraft/ancient_city

execute anchored eyes positioned ^ ^ ^ if entity @s[advancements={unbound:chest/minecraft/abandoned_mineshaft=true}] run function unbound:chest_insert/raycast/minecraft/abandoned_mineshaft

execute anchored eyes positioned ^ ^ ^ if entity @s[advancements={unbound:chest/minecraft/pillager_outpost=true}] run function unbound:chest_insert/raycast/minecraft/pillager_outpost
  
execute anchored eyes positioned ^ ^ ^ if entity @s[advancements={unbound:chest/minecraft/ruined_portal=true}] run function unbound:chest_insert/raycast/minecraft/ruined_portal
  
execute anchored eyes positioned ^ ^ ^ if entity @s[advancements={unbound:chest/minecraft/igloo_chest=true}] run function unbound:chest_insert/raycast/minecraft/igloo_chest
  
execute anchored eyes positioned ^ ^ ^ if entity @s[advancements={unbound:chest/minecraft/shipwreck_treasure=true}] run function unbound:chest_insert/raycast/minecraft/shipwreck_treasure
  
execute anchored eyes positioned ^ ^ ^ if entity @s[advancements={unbound:chest/minecraft/bastion_treasure=true}] run function unbound:chest_insert/raycast/minecraft/bastion_treasure

execute anchored eyes positioned ^ ^ ^ if entity @s[advancements={unbound:chest/minecraft/village_weaponsmith=true}] run function unbound:chest_insert/raycast/minecraft/village_weaponsmith

execute anchored eyes positioned ^ ^ ^ if entity @s[advancements={unbound:chest/minecraft/village_butcher=true}] run function unbound:chest_insert/raycast/minecraft/village_butcher

execute anchored eyes positioned ^ ^ ^ if entity @s[advancements={unbound:chest/terralith/spire_junk=true}] run function unbound:chest_insert/raycast/terralith/spire_junk
  
execute anchored eyes positioned ^ ^ ^ if entity @s[advancements={unbound:chest/terralith/spire_treasure=true}] run function unbound:chest_insert/raycast/terralith/spire_treasure

execute anchored eyes positioned ^ ^ ^ if entity @s[advancements={unbound:chest/terralith/mage_treasure=true}] run function unbound:chest_insert/raycast/terralith/mage_treasure

execute anchored eyes positioned ^ ^ ^ if entity @s[advancements={unbound:chest/terralith/global_bombs=true}] run function unbound:chest_insert/raycast/terralith/global_bombs

execute anchored eyes positioned ^ ^ ^ if entity @s[advancements={unbound:chest/terralith/village_fortified_archer=true}] run function unbound:chest_insert/raycast/terralith/village_fortified_archer

execute anchored eyes positioned ^ ^ ^ if entity @s[advancements={unbound:chest/terralith/village_fortified_food=true}] run function unbound:chest_insert/raycast/terralith/village_fortified_food

execute anchored eyes positioned ^ ^ ^ if entity @s[advancements={unbound:chest/structory/library_high=true}] run function unbound:chest_insert/raycast/structory/library_high

execute anchored eyes positioned ^ ^ ^ if entity @s[advancements={unbound:chest/terralith/global_farm=true}] run function unbound:chest_insert/raycast/terralith/global_farm



advancement revoke @s only unbound:chest/open
