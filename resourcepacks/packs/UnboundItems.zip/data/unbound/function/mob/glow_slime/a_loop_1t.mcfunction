
execute as @e[type=item_display,tag=unbound_glow_slime_model] at @s run function unbound:mob/glow_slime/a_main
