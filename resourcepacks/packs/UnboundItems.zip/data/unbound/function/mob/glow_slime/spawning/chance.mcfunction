execute if predicate unbound:spawn_conditions/glow_slime at @s run function unbound:mob/glow_slime/spawning/summon_group
tag @s add unbound_spawn_checked