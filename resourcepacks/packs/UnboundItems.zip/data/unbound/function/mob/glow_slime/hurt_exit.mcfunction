
data modify entity @s item.components."minecraft:custom_model_data".floats set value [4376028]
scoreboard players reset @s unbound_mob_anim