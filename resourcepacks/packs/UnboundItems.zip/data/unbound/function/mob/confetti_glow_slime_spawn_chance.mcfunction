execute if predicate unbound:spawn_conditions/glow_slime at @s run function unbound:mob/glow_slime/spawning/summon_group

execute if predicate unbound:spawn_conditions/confetti_creeper at @s run function unbound:mob/confetti_creeper/spawn

tag @s add unbound_spawn_checked