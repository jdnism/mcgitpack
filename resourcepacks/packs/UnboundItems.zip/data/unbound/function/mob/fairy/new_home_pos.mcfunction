

data modify entity @s home_radius set value 16


data modify entity @s home_pos set from entity @s Pos






tag @s remove unbound_leashed