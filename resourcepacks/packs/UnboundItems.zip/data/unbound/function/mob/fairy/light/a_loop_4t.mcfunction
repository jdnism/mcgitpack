
execute as @e[type=marker,tag=unbound_fairy_light] at @s run function unbound:mob/fairy/light/a_main