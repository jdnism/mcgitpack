
execute positioned ~ ~-1 ~ if block ~ ~ ~ #air if block ~ ~-1 ~ #unbound:flowers align zyx positioned ~.5 ~.5 ~.5 run function unbound:mob/fairy/light/summon {light:6}
execute positioned ~ ~ ~ if block ~ ~ ~ #air if block ~ ~-1 ~ #unbound:flowers align zyx positioned ~.5 ~.5 ~.5 run function unbound:mob/fairy/light/summon {light:6}
execute positioned ~ ~1 ~ if block ~ ~ ~ #air if block ~ ~-1 ~ #unbound:flowers align zyx positioned ~.5 ~.5 ~.5 run function unbound:mob/fairy/light/summon {light:6}
execute positioned ~ ~2 ~ if block ~ ~ ~ #air if block ~ ~-1 ~ #unbound:flowers align zyx positioned ~.5 ~.5 ~.5 run function unbound:mob/fairy/light/summon {light:6}
execute positioned ~ ~3 ~ if block ~ ~ ~ #air if block ~ ~-1 ~ #unbound:flowers align zyx positioned ~.5 ~.5 ~.5 run function unbound:mob/fairy/light/summon {light:6}

