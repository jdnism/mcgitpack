


execute if predicate unbound:chance/33_percent run playsound block.amethyst_block.chime neutral @a[distance=..64] ~ ~ ~ .2 2

execute if predicate unbound:chance/33_percent run playsound block.amethyst_block.chime neutral @a[distance=..64] ~ ~ ~ .2 1.5

execute if predicate unbound:chance/33_percent run playsound block.amethyst_block.chime neutral @a[distance=..64] ~ ~ ~ .2 .6