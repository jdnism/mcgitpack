
execute as @e[type=item_display,tag=unbound_fairy_display] at @s run function unbound:mob/fairy/a_main