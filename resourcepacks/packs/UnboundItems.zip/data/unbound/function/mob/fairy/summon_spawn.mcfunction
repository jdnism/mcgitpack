function unbound:mob/fairy/summon

kill @s