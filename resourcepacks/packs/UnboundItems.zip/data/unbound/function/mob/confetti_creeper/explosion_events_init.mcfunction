
effect give @s resistance 10000 255 true
data modify entity @s Health set value 0.01
function unbound:mob/confetti_creeper/explosion_events
