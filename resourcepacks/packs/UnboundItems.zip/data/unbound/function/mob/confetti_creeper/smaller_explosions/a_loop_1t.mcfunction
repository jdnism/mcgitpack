
execute as @e[type=marker,tag=unbound_confetti_creeper_small_explosion] at @s run function unbound:mob/confetti_creeper/smaller_explosions/a_main
