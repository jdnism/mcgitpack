
execute as @e[type=item_display,tag=unbound_confetti_creeper_model] at @s run function unbound:mob/confetti_creeper/a_main
