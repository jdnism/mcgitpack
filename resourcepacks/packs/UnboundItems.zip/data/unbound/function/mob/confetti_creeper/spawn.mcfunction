function unbound:mob/confetti_creeper/summon
tp @s ~ -500 ~