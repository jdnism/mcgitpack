tag @s add unbound_phantom_rider_alone
data modify entity @s Motion[1] set value 0.2
execute on vehicle run kill @s