rotate @s facing entity @p[distance=..48,gamemode=!spectator]

execute at @s run tp @s ^ ^ ^6
