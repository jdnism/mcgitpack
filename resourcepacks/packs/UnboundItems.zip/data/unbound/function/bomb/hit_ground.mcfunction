execute if score @s unbound_count matches ..24 run scoreboard players set @s unbound_count2 25
tp @s ~ ~1 ~