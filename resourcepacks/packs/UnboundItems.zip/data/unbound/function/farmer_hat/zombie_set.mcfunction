#original is 35
#this is a 25% reduction
attribute @s follow_range base set 26
tag @s add unbound_zombie_decreased_range