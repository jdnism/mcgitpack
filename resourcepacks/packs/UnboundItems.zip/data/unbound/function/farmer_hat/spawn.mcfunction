data modify entity @s DeathLootTable set value "unbound:farmer_hat"

