
attribute @s follow_range base set 35
tag @s remove unbound_zombie_decreased_range