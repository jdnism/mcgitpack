execute if predicate unbound:equipped/amulet run playsound item.armor.equip_netherite player @s ~ ~ ~ .8 1.8
execute if predicate unbound:equipped/amulet run playsound item.armor.equip_diamond player @s ~ ~ ~ .7 1.3
execute if predicate unbound:equipped/necrotic_amulet_offhand run function unbound:amulets/necrotic/low_health_init_anim