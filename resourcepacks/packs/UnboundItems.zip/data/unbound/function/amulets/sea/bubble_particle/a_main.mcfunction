
scoreboard players add @s unbound_count 1

particle bubble ~ ~ ~ 0 0 0 1 10 force @a[distance=..64]

execute if score @s unbound_count matches 0.. run kill @s

schedule function unbound:amulets/sea/bubble_particle/loop_1t 1t