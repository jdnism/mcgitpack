effect give @e[distance=..7,type=#unbound:herding_mobs] speed 1 0 false

execute as @e[distance=..10,type=wolf] run function unbound:amulets/herding/wolf