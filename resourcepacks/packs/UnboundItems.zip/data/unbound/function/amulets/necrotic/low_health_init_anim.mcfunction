playsound minecraft:block.lava.ambient player @a[distance=..32] ~ ~ ~ .2 2
playsound minecraft:entity.ender_dragon.flap player @a[distance=..32] ~ ~ ~ .5 1.5

playsound minecraft:block.trial_spawner.spawn_item_begin player @a[distance=..32] ~ ~ ~ 1.5 1.5

playsound entity.warden.heartbeat player @a[distance=..16] ~ ~ ~ 1 1.5

particle entity_effect{color:[0.639,0.043,0.204,1.00]} ~ ~1 ~ .3 .5 .3 1 20 force @a[distance=..64]


