
execute if predicate unbound:equipped/necrotic_amulet_offhand run item modify entity @s weapon.offhand unbound:necrotic1
execute if predicate unbound:equipped/necrotic_amulet_mainhand run item modify entity @s weapon.mainhand unbound:necrotic1

tag @s remove unbound_strengthChecked
