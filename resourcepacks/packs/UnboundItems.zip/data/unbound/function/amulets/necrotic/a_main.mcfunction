execute if predicate unbound:equipped/necrotic_amulet_offhand run function unbound:amulets/necrotic/low_health
