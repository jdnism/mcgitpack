execute if predicate unbound:equipped/fire_amulet_offhand run function unbound:amulets/fire/a_main

execute if predicate unbound:equipped/necrotic_amulet_offhand run function unbound:amulets/necrotic/a_main

execute if predicate unbound:equipped/sea_amulet_offhand run function unbound:amulets/sea/a_main

execute if score 10tick unbound_clock matches 1 if predicate unbound:equipped/herding_amulet_offhand run function unbound:amulets/herding/a_main