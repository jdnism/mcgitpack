



execute if predicate unbound:equipped/fire_amulet_mainhand run item modify entity @s weapon unbound:fire_amulet2.5
execute if predicate unbound:equipped/fire_amulet_offhand run item modify entity @s weapon.offhand unbound:fire_amulet2.5

scoreboard players set @s unbound_fire_time_on_fire 320



tag @s remove unbound_fire_amulet_noRes