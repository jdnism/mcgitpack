
execute if predicate unbound:equipped/magnet run function unbound:magnet/a_main
execute if predicate unbound:equipped/amulet_offhand run function unbound:amulets/a_main
execute if predicate unbound:equipped/sculk_radar run function unbound:sculk_radar/a_main
execute if predicate unbound:equipped/bone_wand run function unbound:bone_wand/a_main
