#this file is used for compatibility
#allows other datapacks to check whether this current datapack is installed by whether this file exists or not
#command used by other packs -> execute store success score [player] [objective] run function unbound:installed

return 1