scoreboard players add @s unbound_hood_time 1


execute if score @s unbound_hood_time matches 80.. run function unbound:hood/time_end