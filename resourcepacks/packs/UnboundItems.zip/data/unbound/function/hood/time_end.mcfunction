
scoreboard players reset @s unbound_hood_time