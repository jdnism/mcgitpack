


playsound entity.phantom.ambient player @a[distance=..32] ~ ~ ~ 1 .7
playsound entity.vex.charge player @a[distance=..32] ~ ~ ~ .2 2

#effects
effect give @s speed 3 1 false





advancement revoke @s only unbound:technical/entity_attacked_player_hood