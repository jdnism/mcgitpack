
execute store result score @s unbound_uuid1 run data get entity @s UUID[0]
execute store result score @s unbound_uuid2 run data get entity @s UUID[1]
execute store result score @s unbound_uuid3 run data get entity @s UUID[2]
execute store result score @s unbound_uuid4 run data get entity @s UUID[3]

