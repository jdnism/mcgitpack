
tellraw @s [{"text": " "}]

tellraw @s [{"text":"  "},{"translate":"Glow Slime","color":"#5ba3f5","underlined":true,"hover_event":{"action":"show_text","value":[{"translate":"Click to summon"}]},"click_event":{"action":"run_command","command":"function unbound:mob/glow_slime/summon_random_size"}}]

tellraw @s [{"text": " "}]


tellraw @s [{"text":"  "},{"translate":"Confetti Creeper","color":"#5ba3f5","underlined":true,"hover_event":{"action":"show_text","value":[{"translate":"Click to summon"}]},"click_event":{"action":"run_command","command":"function unbound:mob/confetti_creeper/summon"}}]


tellraw @s [{"text": " "}]


tellraw @s [{"text":"  "},{"translate":"Phantom Rider","color":"#5ba3f5","underlined":true,"hover_event":{"action":"show_text","value":[{"translate":"Click to summon"}]},"click_event":{"action":"run_command","command":"function unbound:mob/phantom_rider/summon"}}]



tellraw @s [{"text": " "}]

tellraw @s [{"text":"  "},{"translate":"Fairy","color":"#5ba3f5","underlined":true,"hover_event":{"action":"show_text","value":[{"translate":"Click to summon"}]},"click_event":{"action":"run_command","command":"function unbound:mob/fairy/summon"}}]


tellraw @s [{"text": " "}]



tellraw @s [{"text": " "}]

