
tellraw @s [{"text": " "}]

tellraw @s [{"text":"  "},{"translate":"Bomb","color":"#5ba3f5","underlined":true,"hover_event":{"action":"show_text","value":[{"translate":"Click to give"}]},"click_event":{"action":"run_command","command":"/function unbound:_give/bomb"}},{"text":"                    "},{"translate":"Glow Slime Ball","color":"#5ba3f5","underlined":true,"hover_event":{"action":"show_text","value":[{"translate":"Click to give"}]},"click_event":{"action":"run_command","command":"/function unbound:_give/glow_slime_ball"}},{"text":"    "}]

tellraw @s [{"text": " "}]


tellraw @s [{"text":"  "},{"translate":"Spectral Bottle","color":"#5ba3f5","underlined":true,"hover_event":{"action":"show_text","value":[{"translate":"Click to give"}]},"click_event":{"action":"run_command","command":"/function unbound:_give/spectral_bottle"}},{"text":"       "},{"translate":"Phantom Cloak","color":"#5ba3f5","underlined":true,"hover_event":{"action":"show_text","value":[{"translate":"Click to give"}]},"click_event":{"action":"run_command","command":"/function unbound:_give/phantom_cloak"}},{"text":"    "}]


tellraw @s [{"text": " "}]

tellraw @s [{"text":"  "},{"translate":"Golden Beetroot","color":"#5ba3f5","underlined":true,"hover_event":{"action":"show_text","value":[{"translate":"Click to give"}]},"click_event":{"action":"run_command","command":"/function unbound:_give/golden_beetroot"}},{"text":"      "},{"translate":"Rabbit Boots","color":"#5ba3f5","underlined":true,"hover_event":{"action":"show_text","value":[{"translate":"Click to give"}]},"click_event":{"action":"run_command","command":"/function unbound:_give/rabbit_boots"}},{"text":"    "}]


tellraw @s [{"text": " "}]

tellraw @s [{"text":"  "},{"translate":"Confetti","color":"#5ba3f5","underlined":true,"hover_event":{"action":"show_text","value":[{"translate":"Click to give"}]},"click_event":{"action":"run_command","command":"/function unbound:_give/confetti"}},{"text":"                "},{"translate":"Spectre Boots","color":"#5ba3f5","underlined":true,"hover_event":{"action":"show_text","value":[{"translate":"Click to give"}]},"click_event":{"action":"run_command","command":"/function unbound:_give/spectre_boots"}},{"text":"    "}]


tellraw @s [{"text": " "}]

tellraw @s [{"text":"  "},{"translate":"Confusion Slime","color":"#5ba3f5","underlined":true,"hover_event":{"action":"show_text","value":[{"translate":"Click to give"}]},"click_event":{"action":"run_command","command":"/function unbound:_give/confusion_slime"}},{"text":"       "},{"translate":"Strider Boots","color":"#5ba3f5","underlined":true,"hover_event":{"action":"show_text","value":[{"translate":"Click to give"}]},"click_event":{"action":"run_command","command":"/function unbound:_give/strider_boots"}},{"text":"    "}]



tellraw @s [{"text": " "}]



tellraw @s [{"translate": "              ","color": "yellow"},{"text":"    - 1/2 -     ","color": "gray","italic": false},{"translate":"","color": "yellow"},{"translate":"","color": "yellow"},{"translate":"Page 2 -->","color":"yellow","underlined":false,"hover_event":{"action":"show_text","value":[{"translate":"Next Page"}]},"click_event":{"action":"run_command","command":"/function unbound:other/menus/give/2"}}]


tellraw @s [{"text": " "}]
