
tellraw @s [{"text": " "}]


tellraw @s [{"text":"  "},{"translate":"Stealth Hood","color":"#5ba3f5","underlined":true,"hover_event":{"action":"show_text","value":[{"translate":"Click to change this setting"}]},"click_event":{"action":"run_command","command":"/function unbound:_give/hood"}},{"text":"        "},{"translate":"Amulet of the Sea","color":"#5ba3f5","underlined":true,"hover_event":{"action":"show_text","value":[{"translate":"Click to change this setting"}]},"click_event":{"action":"run_command","command":"/function unbound:_give/amulet_of_the_sea"}},{"translate":"    "}]

tellraw @s [{"text": " "}]

tellraw @s [{"text":"  "},{"translate":"Farmer Hat","color":"#5ba3f5","underlined":true,"hover_event":{"action":"show_text","value":[{"translate":"Click to change this setting"}]},"click_event":{"action":"run_command","command":"/function unbound:_give/farmer_hat"}},{"text":"         "},{"translate":"Herding Amulet","color":"#5ba3f5","underlined":true,"hover_event":{"action":"show_text","value":[{"translate":"Click to change this setting"}]},"click_event":{"action":"run_command","command":"/function unbound:_give/herding_amulet"}},{"translate":"    "}]

tellraw @s [{"text": " "}]

tellraw @s [{"text":"  "},{"translate":"Magnet","color":"#5ba3f5","underlined":true,"hover_event":{"action":"show_text","value":[{"translate":"Click to change this setting"}]},"click_event":{"action":"run_command","command":"/function unbound:_give/magnet"}},{"text":"               "},{"translate":"Fire Amulet","color":"#5ba3f5","underlined":true,"hover_event":{"action":"show_text","value":[{"translate":"Click to change this setting"}]},"click_event":{"action":"run_command","command":"/function unbound:_give/fire_amulet"}},{"translate":"    "}]

tellraw @s [{"text": " "}]


tellraw @s [{"text":"  "},{"translate":"Bone Wand","color":"#5ba3f5","underlined":true,"hover_event":{"action":"show_text","value":[{"translate":"Click to change this setting"}]},"click_event":{"action":"run_command","command":"/function unbound:_give/bone_wand"}},{"text":"          "},{"translate":"Necrotic Amulet","color":"#5ba3f5","underlined":true,"hover_event":{"action":"show_text","value":[{"translate":"Click to change this setting"}]},"click_event":{"action":"run_command","command":"/function unbound:_give/necrotic_amulet"}},{"translate":"    "}]



tellraw @s [{"text": " "}]


tellraw @s [{"text":"  "},{"translate":"Sculk Radar","color":"#5ba3f5","underlined":true,"hover_event":{"action":"show_text","value":[{"translate":"Click to change this setting"}]},"click_event":{"action":"run_command","command":"/function unbound:_give/sculk_radar"}},{"text":"        "},{"translate":"Strider Statue","color":"#5ba3f5","underlined":true,"hover_event":{"action":"show_text","value":[{"translate":"Click to change this setting"}]},"click_event":{"action":"run_command","command":"/function unbound:_give/strider_statue"}},{"translate":"    "}]

tellraw @s [{"text": " "}]


tellraw @s [{"text":"  "},{"translate":"Shock Arrow","color":"#5ba3f5","underlined":true,"hover_event":{"action":"show_text","value":[{"translate":"Click to change this setting"}]},"click_event":{"action":"run_command","command":"/function unbound:_give/shock_arrow"}},{"text":"       "},{"translate":"Fairy in a Bottle","color":"#5ba3f5","underlined":true,"hover_event":{"action":"show_text","value":[{"translate":"Click to change this setting"}]},"click_event":{"action":"run_command","command":"/function unbound:_give/fairy_in_a_bottle"}},{"translate":"    "}]



tellraw @s [{"text": " "}]


tellraw @s [{"translate": "","color": "yellow"},{"translate":"<-- Page 1","color":"yellow","underlined":false,"hover_event":{"action":"show_text","value":[{"translate":"Previous Page"}]},"click_event":{"action":"run_command","command":"/function unbound:other/menus/give/1"}},{"translate":"    - 2/2 -     ","color": "gray","italic": false},{"translate":"","color": "yellow"},{"translate":"","color": "yellow"}]


tellraw @s [{"text": " "}]

