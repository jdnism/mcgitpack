
function unbound:hood/storage_return with entity @s
scoreboard players set @s unbound_hood_time 1000