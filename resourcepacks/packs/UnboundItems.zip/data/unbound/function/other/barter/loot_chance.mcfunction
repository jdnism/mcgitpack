
execute if predicate unbound:chance/5_percent run function unbound:other/barter/loot_drop

tag @s remove unbound_piglin_bartering