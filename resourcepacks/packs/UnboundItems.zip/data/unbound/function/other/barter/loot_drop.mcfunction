
loot spawn ~ ~1.01 ~ loot unbound:fire_amulet
execute positioned ~ ~1.01 ~ as @n[type=item,distance=..0.5] at @s facing entity @p[distance=..32] eyes run function unbound:other/barter/item_motion