advancement revoke @s only unbound:technical/piglin_barter
execute as @n[type=piglin,nbt={Brain:{memories:{"minecraft:admiring_item":{}}}}] run tag @s add unbound_piglin_bartering
