advancement grant @s only vanilla_refresh:craft/any acacia_boat
advancement grant @s[advancements={unbound:technical/craft/any_stacks=true}] only vanilla_refresh:craft/any_stacks acacia_boat


advancement grant @s[advancements={unbound:technical/craft/strider_boots=true}] only vanilla_refresh:craft/specific/tool_iron iron_boots
advancement grant @s[advancements={unbound:technical/craft/strider_boots=true}] only vanilla_refresh:craft/specific/netherite netherite_axe_smithing

advancement grant @s[advancements={unbound:technical/craft/diamond=true}] only vanilla_refresh:craft/specific/diamond diamond

advancement revoke @s through unbound:technical/craft/any