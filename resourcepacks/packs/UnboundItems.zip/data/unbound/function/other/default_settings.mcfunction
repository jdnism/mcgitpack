execute unless score items_obtainable unbound_config matches -2147483648.. run scoreboard players set items_obtainable unbound_config 1

execute unless score mob_spawns unbound_config matches -2147483648.. run scoreboard players set mob_spawns unbound_config 1