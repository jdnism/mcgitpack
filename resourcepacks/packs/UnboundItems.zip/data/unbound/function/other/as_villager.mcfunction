

execute if entity @s[tag=!unbound_trade_set,nbt={VillagerData:{profession:"minecraft:shepherd",level:1}}] run function unbound:amulets/herding/set_villager

execute if entity @s[tag=!unbound_trade_set,nbt={VillagerData:{profession:"minecraft:farmer",level:2}}] run function unbound:farmer_hat/set_villager