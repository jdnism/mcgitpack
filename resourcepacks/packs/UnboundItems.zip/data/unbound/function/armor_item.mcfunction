
execute if predicate unbound:equipped/amulet run function unbound:amulets/a_main
execute if predicate unbound:equipped/sculk_radar run function unbound:sculk_radar/a_main
