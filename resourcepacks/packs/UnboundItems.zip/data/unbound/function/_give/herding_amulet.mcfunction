

loot give @s loot unbound:herding_amulet