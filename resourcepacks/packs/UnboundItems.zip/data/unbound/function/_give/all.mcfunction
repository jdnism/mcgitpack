

give @s green_stained_glass_pane[max_stack_size=1] 9

loot give @s loot unbound:bomb

loot give @s loot unbound:spectral_bottle

loot give @s loot unbound:golden_beetroot

loot give @s loot unbound:confetti

loot give @s loot unbound:glow_slime_ball

loot give @s loot unbound:confusion_slime

loot give @s loot unbound:shock_arrow

give @s green_stained_glass_pane[max_stack_size=1] 2


loot give @s loot unbound:magnet


loot give @s loot unbound:herding_amulet

loot give @s loot unbound:amulet_of_the_sea

loot give @s loot unbound:fire_amulet

loot give @s loot unbound:necrotic_amulet



loot give @s loot unbound:sculk_radar

loot give @s loot unbound:fairy_in_a_bottle



give @s green_stained_glass_pane[max_stack_size=1] 2


loot give @s loot unbound:bone_wand


loot give @s loot unbound:phantom_cloak



loot give @s loot unbound:rabbit_boots

loot give @s loot unbound:spectre_boots


loot give @s loot unbound:strider_boots


loot give @s loot unbound:farmer_hat

loot give @s loot unbound:hood


loot give @s loot unbound:strider_statue


clear @s green_stained_glass_pane