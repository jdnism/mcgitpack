
schedule function unbound:clock/sculk_radar_interval 24t


scoreboard players set 24tick unbound_clock 0