




scoreboard players set 20tick unbound_clock 0

schedule function unbound:clock/20 20t
