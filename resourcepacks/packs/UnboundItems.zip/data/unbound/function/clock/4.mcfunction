

scoreboard players set 4tick unbound_clock 0

schedule function unbound:clock/4 4t
