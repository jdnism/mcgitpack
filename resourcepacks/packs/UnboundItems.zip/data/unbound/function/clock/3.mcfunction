

scoreboard players set 3tick unbound_clock 0

schedule function unbound:clock/3 3t
