
execute if score @s unbound_count matches 5.. at @s run tp @s ~ ~-.3 ~
execute if score @s unbound_count matches 10.. at @s run tp @s ~ ~-.3 ~
execute if score @s unbound_count matches 20.. at @s run tp @s ~ ~-.3 ~
execute if score @s unbound_count matches 25.. at @s run tp @s ~ ~-.4 ~
execute if score @s unbound_count matches 30.. at @s run tp @s ~ ~-.2 ~
execute if score @s unbound_count matches 40.. at @s run tp @s ~ ~-.2 ~
