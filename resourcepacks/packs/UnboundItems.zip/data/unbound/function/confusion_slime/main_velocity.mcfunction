
execute if score @s unbound_count matches 0..5 at @s run tp @s ^ ^ ^1
execute if score @s unbound_count matches 6..20 at @s run tp @s ^ ^ ^.7
execute if score @s unbound_count matches 21..40 at @s run tp @s ^ ^ ^.4
execute if score @s unbound_count matches 41..200 at @s run tp @s ^ ^ ^.2