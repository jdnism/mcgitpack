
function unbound:bone_wand/box
execute positioned ~ ~1 ~ run function unbound:bone_wand/box