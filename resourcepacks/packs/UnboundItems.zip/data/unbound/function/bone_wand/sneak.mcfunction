scoreboard players add @s unbound_bone_wand_sneak_count 1
function unbound:bone_wand/sneak_timer
tag @s add unbound_player_sneaking