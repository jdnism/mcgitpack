
execute if score 24tick unbound_clock matches 1 run function unbound:sculk_radar/click
