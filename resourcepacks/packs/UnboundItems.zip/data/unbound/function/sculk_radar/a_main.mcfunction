
execute if predicate unbound:equipped/sculk_radar_mainhand unless predicate unbound:equipped/sculk_radar/calibrated_either run function unbound:sculk_radar/not_calibrated/a_main
execute if predicate unbound:equipped/sculk_radar/calibrated_either run function unbound:sculk_radar/a_main_calibrated
