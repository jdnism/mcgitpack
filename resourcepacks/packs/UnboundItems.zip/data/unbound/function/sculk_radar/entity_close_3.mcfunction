
execute if score 24tick unbound_clock matches 7 run playsound minecraft:block.note_block.chime player @a[distance=..32] ~ ~ ~ .26 1
execute if score 24tick unbound_clock matches 1 run function unbound:sculk_radar/click3

execute if score 24tick unbound_clock matches 3 run function unbound:sculk_radar/click3

execute if score 24tick unbound_clock matches 5 run function unbound:sculk_radar/click3

execute if score 24tick unbound_clock matches 7 run function unbound:sculk_radar/click3


#execute if score 24tick unbound_clock matches 19 run function unbound:sculk_radar/click
