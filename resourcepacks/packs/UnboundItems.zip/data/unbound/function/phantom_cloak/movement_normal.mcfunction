
execute if score @s unbound_cloak_dash matches 1..2 rotated ~ 0 positioned ^ ^ ^.8 if block ^ ^ ^.5 #unbound:permeable run tp @s ~ ~ ~
execute if score @s unbound_cloak_dash matches 3..6 rotated ~ 0 positioned ^ ^ ^.12 if block ^ ^ ^.5 #unbound:permeable run tp @s ~ ~ ~
execute if score @s unbound_cloak_dash matches 7..8 rotated ~ 0 positioned ^ ^ ^.06 if block ^ ^ ^.5 #unbound:permeable run tp @s ~ ~ ~
