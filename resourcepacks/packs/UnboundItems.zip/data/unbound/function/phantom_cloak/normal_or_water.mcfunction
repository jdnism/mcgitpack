
execute unless block ~ ~ ~ #unbound:water rotated ~ 0 run function unbound:phantom_cloak/movement
execute if block ~ ~ ~ #unbound:water rotated ~ ~ run function unbound:phantom_cloak/movement
