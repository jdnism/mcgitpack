tag @s remove unbound_cloak_left
tag @s remove unbound_cloak_right
tag @s remove unbound_cloak_back

#tag @s remove unbound_cloak_mob_boost

tag @s remove unbound_cloak_pogo_boost

scoreboard players reset @s unbound_cloak_dash
scoreboard players reset @s unbound_cloak_dash_count