
execute if score @s unbound_cloak_dash matches 04 run effect clear @s minecraft:levitation
execute if score @s unbound_cloak_dash matches 04 run effect give @s minecraft:levitation 1 3 true

execute if score @s unbound_cloak_dash matches 07 run effect clear @s minecraft:levitation
execute if score @s unbound_cloak_dash matches 07 run effect give @s minecraft:levitation 1 0 true

execute if score @s unbound_cloak_dash matches 10 run effect clear @s minecraft:levitation
