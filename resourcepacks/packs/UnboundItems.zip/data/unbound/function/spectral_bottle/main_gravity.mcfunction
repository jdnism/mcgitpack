
execute if score @s unbound_count matches 10.. at @s run tp @s ~ ~-.1 ~
execute if score @s unbound_count matches 15.. at @s run tp @s ~ ~-.2 ~
execute if score @s unbound_count matches 20.. at @s run tp @s ~ ~-.3 ~
execute if score @s unbound_count matches 25.. at @s run tp @s ~ ~-.3 ~
execute if score @s unbound_count matches 35.. at @s run tp @s ~ ~-.3 ~
execute if score @s unbound_count matches 45.. at @s run tp @s ~ ~-.3 ~
