
execute as @e[type=item_display,tag=unbound_spectral_bottle] at @s run function unbound:spectral_bottle/entity