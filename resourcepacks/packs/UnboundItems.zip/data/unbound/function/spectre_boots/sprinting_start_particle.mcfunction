playsound minecraft:entity.breeze.wind_burst player @a[distance=..32] ~ ~ ~ .2 .8

particle poof ~ ~.1 ~ .2 .1 .2 .15 15 force @a[distance=..64]

item modify entity @s armor.feet unbound:spectre_boots_wind