execute if predicate unbound:chance/25_percent positioned ^ ^ ^-.1 run particle poof ~ ~ ~ ^ ^ ^-100000000000000000 .000000000000000002 0 force @a[distance=..64]
execute if predicate unbound:chance/25_percent positioned ^ ^ ^-.1 rotated ~5 ~ run particle poof ~ ~ ~ ^ ^ ^-100000000000000000 .000000000000000002 0 force @a[distance=..64]
execute if predicate unbound:chance/25_percent positioned ^ ^ ^-.1 rotated ~-5 ~ run particle poof ~ ~ ~ ^ ^ ^-100000000000000000 .000000000000000002 0 force @a[distance=..64]
