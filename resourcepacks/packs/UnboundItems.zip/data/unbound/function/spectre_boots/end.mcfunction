execute if score @s unbound_spectre_time matches 25.. run function unbound:spectre_boots/end_anim
scoreboard players reset @s unbound_spectre_time