

execute unless score found_block unbound_storage matches 1 positioned ^ ^ ^ run function unbound:block/strider_statue/find_3
execute unless score found_block unbound_storage matches 1 positioned ^ ^ ^1 run function unbound:block/strider_statue/find_3
execute unless score found_block unbound_storage matches 1 positioned ^ ^ ^2 run function unbound:block/strider_statue/find_3
execute unless score found_block unbound_storage matches 1 positioned ^ ^ ^3 run function unbound:block/strider_statue/find_3
execute unless score found_block unbound_storage matches 1 positioned ^ ^ ^4 run function unbound:block/strider_statue/find_3
execute unless score found_block unbound_storage matches 1 positioned ^ ^ ^5 run function unbound:block/strider_statue/find_3
execute unless score found_block unbound_storage matches 1 positioned ^ ^ ^6 run function unbound:block/strider_statue/find_3


advancement revoke @s only unbound:technical/place/strider_statue

scoreboard players reset found_block unbound_storage