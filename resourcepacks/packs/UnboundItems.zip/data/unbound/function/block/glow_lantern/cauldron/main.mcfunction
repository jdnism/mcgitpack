execute unless block ~ ~ ~ water_cauldron run function unbound:block/glow_lantern/cauldron/break


execute if score @s unbound_block_level matches 4.. run function unbound:block/glow_lantern/cauldron/anim