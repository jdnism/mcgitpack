scoreboard players reset @s unbound_rabbit_time
attribute @s jump_strength modifier remove unbound:rabbit_boots_jump
