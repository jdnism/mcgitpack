
item modify entity @s weapon.offhand {function:"set_enchantments",enchantments:{"unbound:technical/move":1}}
